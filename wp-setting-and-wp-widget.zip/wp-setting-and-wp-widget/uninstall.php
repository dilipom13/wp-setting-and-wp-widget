<?php
if (!defined('ABSPATH')) {
    exit;
}
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ){
    die;
} 
delete_option('wp_settings');