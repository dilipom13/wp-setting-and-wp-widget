=== Wp Setting & Wp Widget ===

- Create one setting page and add setting fields like Title, Description, Editor Content, Date, Image, and Color Picker.
- All Setting options are stored in the Database.
- When Clicking on 'Reset All Settings' all fields will be blank.
- Create one widget, widget fields like title, first name, last name, and sex.