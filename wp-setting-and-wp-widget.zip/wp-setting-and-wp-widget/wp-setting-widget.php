<?php
/**
 * Plugin Name: Wp Setting & Wp Widget
 * Plugin URI: https://dsm.com/
 * Description: Wp Setting and Wp Widget Plugin.
 * Author: Dilip Modhavadiya
 * Author URI: https://dsm.com/
 * Version: 1.0.0
 * Text Domain: wp-setting-and-wp-widget
 * Domain Path: /languages
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}
if( !defined( 'WPSW_VERSION' ) ) {
	define( 'WPSW_VERSION', '1.0.0' ); // Plugin Version
}
if( !defined( 'WPSW_URL' ) ) {
    define( 'WPSW_URL', plugin_dir_url( __FILE__ ) ); // Plugin url
}
if ( ! defined( 'WPSW_PLUGIN_DIR' ) )	    
{
    define( 'WPSW_PLUGIN_DIR'   , plugin_dir_path( __FILE__ ) ); // Plugin Dir Path
}
require_once( WPSW_PLUGIN_DIR . '/admin/wp-setting.php' );
require_once( WPSW_PLUGIN_DIR . '/admin/wp-widget.php' ); 