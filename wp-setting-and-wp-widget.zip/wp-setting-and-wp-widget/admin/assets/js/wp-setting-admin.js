jQuery(document).ready(function($) {
    // Image Media
    $('#wp_settings_image_button').click(function(e) {
        e.preventDefault();
        var image_frame;
        if (image_frame) {
            image_frame.open();
        }
        // Define image_frame as wp.media object
        image_frame = wp.media({
            title: 'Select Media',
            multiple: false,
            library: {
                type: 'image',
            }
        });

        image_frame.on('close', function() {
            // On close, get selections and save to the hidden input
            // plus other AJAX stuff to refresh the image preview
            var selection = image_frame.state().get('selection');
            var gallery_ids = selection.map(function(attachment) {
                attachment = attachment.toJSON();
                return attachment.url;
            }).join();
            $('#my_setting_image').val(gallery_ids);
        });

        image_frame.on('open', function() {

            var selection = image_frame.state().get('selection');
            var ids = $('#my_setting_image').val().split(',');
            ids.forEach(function(id) {
                var attachment = wp.media.attachment(id);
                attachment.fetch();
                selection.add(attachment ? [attachment] : []);
            });

        });

        image_frame.open();
    });

    // Color Picker
    $('.my-color-field').wpColorPicker();
});