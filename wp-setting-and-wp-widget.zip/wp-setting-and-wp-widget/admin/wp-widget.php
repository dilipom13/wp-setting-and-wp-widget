<?php
class Wpd_Ws_Example_Widget extends WP_Widget {

    // Constructor
    public function __construct() {
        parent::__construct(
            'wpd_ws_example_widget', // Base ID
            __('Wpd Ws Example Widget', 'wp-setting-and-wp-widget'), // Name
            array('description' => __('A widget that displays user information.', 'wp-setting-and-wp-widget')) // Args
        );
    }

public function widget($args, $instance) {

    echo $args['before_widget'];
    if (!empty($instance['title'])) {
        echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
    }

    if ( !empty($instance['first_name']) || !empty($instance['last_name']) ) 
    {
    echo '<p> Hello, My Name is '. esc_html($instance['first_name']).' '. esc_html($instance['last_name']). '</p>';
    }
    
    if (!empty($instance['display_sex']) && $instance['display_sex'] == 'on') {
    
        if (!empty($instance['sex'])) {
            echo '<p>Sex: ' . esc_html(ucfirst($instance['sex'])) . '</p>';
        }
    }
    echo $args['after_widget'];
}


    // Back-end widget form
    public function form($instance) {
        
        $title      = !empty($instance['title'])      ? $instance['title']      : '';
        $first_name = !empty($instance['first_name']) ? $instance['first_name'] : '';
        $last_name  = !empty($instance['last_name'])  ? $instance['last_name']  : '';
        $sex        = !empty($instance['sex'])        ? $instance['sex']        : '';
        $errors     = !empty($instance['errors'])     ? $instance['errors']     : array();
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'wp-setting-and-wp-widget'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>

        <!-- First Name field -->
        <p>
            <label for="<?php echo $this->get_field_id('first_name'); ?>"><?php _e('First Name:', 'wp-setting-and-wp-widget'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('first_name'); ?>" name="<?php echo $this->get_field_name('first_name'); ?>" type="text" value="<?php echo esc_attr($first_name); ?>">
            <?php if (!empty($errors['first_name'])): ?>
                <br><small style="color:red;"><?php echo esc_html($errors['first_name']); ?></small>
            <?php endif; ?>
        </p>

        <!-- Last Name field -->
        <p>
            <label for="<?php echo $this->get_field_id('last_name'); ?>"><?php _e('Last Name:', 'wp-setting-and-wp-widget'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('last_name'); ?>" name="<?php echo $this->get_field_name('last_name'); ?>" type="text" value="<?php echo esc_attr($last_name); ?>">
            <?php if (!empty($errors['last_name'])): ?>
                <br><small style="color:red;"><?php echo esc_html($errors['last_name']); ?></small>
            <?php endif; ?>
        </p>

        <!-- Sex field -->
        <p>
            <label for="<?php echo $this->get_field_id('sex'); ?>"><?php _e('Sex:', 'wp-setting-and-wp-widget'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('sex'); ?>" name="<?php echo $this->get_field_name('sex'); ?>">
                <option value=""<?php selected($sex, ''); ?>><?php _e('---Select---', 'wp-setting-and-wp-widget'); ?></option>
                <option value="male"<?php selected($sex, 'male'); ?>><?php _e('Male', 'wp-setting-and-wp-widget'); ?></option>
                <option value="female"<?php selected($sex, 'female'); ?>><?php _e('Female', 'wp-setting-and-wp-widget'); ?></option>
            </select>
        </p>
        <!----Start Checkbox functionality---->
        <p>
            <input class="checkbox" type="checkbox" <?php checked($instance['display_sex'], 'on'); ?> id="<?php echo $this->get_field_id('display_sex'); ?>" name="<?php echo $this->get_field_name('display_sex'); ?>" /> 
            <label for="<?php echo $this->get_field_id('display_sex'); ?>"><?php _e('Display Sex', 'wp-setting-and-wp-widget'); ?></label>
        </p>

        <?php
    }

    // Updating widget replacing old instances with new
    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['errors'] = array(); 

        // Validate and sanitize the title
        $instance['title'] = strip_tags($new_instance['title']);

        // Start First Name Valiation
        $trimmed_first_name = trim($new_instance['first_name']);
        if (empty($trimmed_first_name)) {
            $instance['errors']['first_name'] = 'Please enter a valid first name.';
            $instance['first_name'] = '';
        } else {
            $instance['first_name'] = sanitize_text_field($new_instance['first_name']);
        }

        // Start Last Name Valiation
        $trimmed_last_name = trim($new_instance['last_name']);
        if (empty($trimmed_last_name)) {
            $instance['errors']['last_name'] = 'Please enter a valid last name.';
            $instance['last_name'] = '';
        } else {
            $instance['last_name'] = sanitize_text_field($new_instance['last_name']);
        } 
        $instance['sex'] = (isset($new_instance['sex']) && in_array($new_instance['sex'], ['male', 'female'], true)) ? $new_instance['sex'] : '';
        $instance['display_sex'] = !empty($new_instance['display_sex']) ? 'on' : 'off';


        return $instance;
    }
}
function register_wpd_ws_example_widget() {
    register_widget('Wpd_Ws_Example_Widget');
}
add_action('widgets_init', 'register_wpd_ws_example_widget');