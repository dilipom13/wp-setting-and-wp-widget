<?php
class Wp_Settings_Page {
    public function __construct() {
        add_action('admin_menu', array($this, 'wp_settings_page_menu'));
        add_action('admin_enqueue_scripts', array($this, 'custom_plugin_enqueue_scripts'));
        add_action('admin_init', array($this, 'custom_settings_widget_register_settings'));
    }

    public function custom_plugin_enqueue_scripts($hook) {
        
        wp_register_script('wp-setting-admin', WPSW_URL . 'admin/assets/js/wp-setting-admin.js', array('jquery'), WPSW_VERSION, true);
        wp_enqueue_script('wp-setting-admin');

        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_style('jquery-ui', WPSW_URL . 'admin/assets/css/jquery-ui.css');
        wp_enqueue_style('wp-setting-admin', WPSW_URL . 'admin/assets/css/wp-setting-admin.css');

        

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
    }

    public function wp_settings_page_menu() {
        add_menu_page(
            'Custom Settings & Widget Page', 
            'WP Settings & Widget Page', 
            'manage_options', 
            'custom-settings-widget', 
            array($this, 'wp_settings_page_fields')
        );
    }

    public function wp_settings_page_fields() {

        if (!current_user_can('manage_options')) {
            return;
        }
        $output = get_option('wp_settings'); 
    ?>
    <div class="wrap wp-custom-cls">
        <h1><?php _e('WP Settings & Widget Page','wp-setting-and-wp-widget'); ?></h1>
        <form method="post" action="options.php">
            
            <input type="submit" name="reset_all_settings" id="reset_all_settings" class="button button-primary" value="<?php esc_attr_e('Reset All Settings', 'wp-setting-and-wp-widget'); ?>">
                <?php wp_nonce_field('custom-settings-widget-settings-group-options'); ?>
            <?php
            settings_fields('custom-settings-widget-settings-group');
            do_settings_sections('custom-settings-widget-settings-group');   
            ?>
            <?php submit_button(); ?>
            <!-- Add your settings fields here -->
            <table class="form-table">
            <strong><?php _e('WP Settings & Widget Page','wp-setting-and-wp-widget'); ?></strong>
                <tbody>
                    <!----Title---->
                    <tr valign="top">
					    <th scope="row"><label><?php _e( 'Title', 'wp-setting-and-wp-widget' ); ?></label></th>
					    <td style="width: auto;display: inline-block;"> 
                        <input required="" type="text" class="regular-text" id="rs-form_First Name" name="wp_settings[title]" value="<?php echo esc_attr($output['title'] ?? ''); ?>">
					 	<label for="rs-form_authorfname_label" style="display:block; padding: 10px"><?php _e( 'Enter a title.', 'wp-setting-and-wp-widget' ); ?></label>
					    </td>
				    </tr>
                    <!----Description---->
                    <tr valign="top">
                        <th scope="row"><label for="wp_settings_description"><?php _e( 'Description', 'wp-setting-and-wp-widget' ); ?></label></th>
                        <td>
                            <textarea id="wp_settings_description" name="wp_settings[description]" class="large-text" rows="5" style="height: 125px;width: 347px;"><?php echo esc_textarea($output['description'] ?? ''); ?></textarea>
                            <label for="rs-form_authorfname_label" style="display:block; padding: 10px"><?php _e( 'Enter a description.', 'wp-setting-and-wp-widget' ); ?></label>
                        </td>
                    </tr>
                    <!----Editor Content---->
                    <tr valign="top">
                        <th scope="row"><label for="wp_settings_editor"><?php _e( 'Editor Content', 'wp-setting-and-wp-widget' ); ?></label></th>
                        <td>
                            <?php
                                $editor_id = 'wp_settings_editor';
                                $editor_content = $output['editor_content'] ?? '';
                                $settings = array(
                                    'textarea_name' => 'wp_settings[editor_content]',
                                    'textarea_rows' => 10,
                                    'editor_height' => 300,
                                    'editor_css' => '<style>#wp-wp_settings_editor-wrap { max-width: 700px; }</style>', 
                                );
                                wp_editor($editor_content, $editor_id, $settings);
                            ?>
                            <label for="rs-form_authorfname_label" style="display:block; padding: 10px"><?php _e( 'Enter the editor content.', 'wp-setting-and-wp-widget' ); ?></label>
                        </td>
                    </tr>
                    <!----Date---->
                    <tr valign="top">
                            <th scope="row"><label for="my_setting_date"><?php _e( 'Date', 'wp-setting-and-wp-widget' ); ?></label></th>
                            <td>
                                <input type="date" id="my_setting_date" name="wp_settings[my_setting_date]" value="<?php echo esc_attr($output['my_setting_date'] ?? ''); ?>" class="regular-text">
                                <label for="rs-form_date_label" style="display:block; padding: 10px"><?php _e( 'Enter a date.', 'wp-setting-and-wp-widget' ); ?></label>
                            </td>
                        </tr>
                    <!----Image---->
                    <tr valign="top">
                        <th scope="row"><label for="my_setting_image"><?php _e( 'Image', 'wp-setting-and-wp-widget' ); ?></label></th>
                        <td>
                            <input type="text" id="my_setting_image" name="wp_settings[my_setting_image]" value="<?php echo esc_url($output['my_setting_image'] ?? ''); ?>" class="regular-text">
                            <input type="button" class="button" id="wp_settings_image_button" value="Choose Image" />
                            <?php if ( ! empty( $output['my_setting_image'] ) ) : ?>
                                <img src="<?php echo esc_url( $output['my_setting_image'] ); ?>" alt="Setting Image" style="max-width: 20%; height: auto; display: block; margin-top: 10px;">
                            <?php endif; ?>
                            <label for="rs-form_image_label" style="display:block; padding: 10px"><?php _e( 'Enter an image URL or use the media uploader.', 'wp-setting-and-wp-widget' ); ?></label>
                        </td>
                    </tr>
                    <!----Color Picker---->
                    <tr valign="top">
                        <th scope="row"><label for="wp_settings_color"><?php _e( 'Color Picker', 'wp-setting-and-wp-widget' ); ?></label></th>
                        <td>
                            <input type="text" id="wp_settings_color" name="wp_settings[my_setting_color]" value="<?php echo esc_attr($output['my_setting_color'] ?? ''); ?>" class="my-color-field" data-default-color="#effeff" />
                            <label for="rs-form_color_label" style="display:block; padding: 10px"><?php _e( 'Choose a color.', 'wp-setting-and-wp-widget' ); ?></label>
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
        <?php
    }
    public function custom_settings_widget_register_settings() {
        register_setting('custom-settings-widget-settings-group', 'wp_settings', array($this, 'custom_settings_widget_sanitize_options'));
        if (isset($_POST['reset_all_settings']) && check_admin_referer('custom-settings-widget-settings-group-options')) {
            $this->reset_settings();
            add_settings_error(
                'wp_settings',
                'settings_reset',
                __('Settings have been reset to defaults.', 'wp-setting-and-wp-widget'),
                'updated'
            );
            wp_redirect(add_query_arg('page', 'custom-settings-widget', admin_url('admin.php')));
            exit;
        }
    }
    public function custom_settings_widget_sanitize_options($input) {
        $output = get_option('wp_settings');
        /*echo '<pre>';
        print_r($output);
        exit();*/
        if (isset($input['title'])) {
            $output['title'] = sanitize_text_field($input['title']);
        }
        if (isset($input['description'])) {
            $output['description'] = wp_kses_post($input['description']);
        }
        if(isset($input['editor_content'])){
            $output['editor_content'] = wp_kses_post($input['editor_content']);
        }
        if(isset($input['my_setting_date'])){
            $output['my_setting_date'] = sanitize_text_field($input['my_setting_date']);
        }
        if(isset($input['my_setting_image'])){
            $output['my_setting_image'] = sanitize_text_field($input['my_setting_image']);
        }
        if(isset($input['my_setting_color'])){
            $output['my_setting_color'] = sanitize_text_field($input['my_setting_color']);
        }
        return $output;
    }
    private function reset_settings() {
        delete_option('wp_settings');
    }
    
}
$wp_settings_page = new Wp_Settings_Page();